const express = require('express');
const { MongoClient } = require('mongodb');
const bodyParser = require('body-parser');
const path = require('path');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = 8080;
const HOST = '192.168.20.43';
const jwtSecret = 's3gur@_k3y_2024!@@';

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'static')));

// Configuração MongoDB
const mongoUrl = 'mongodb://jolyne:cat123@192.168.20.43:27017';
const dbName = 'testeifc';
let db;

// Conectar ao MongoDB
async function connectToMongo() {
    try {
        const client = await MongoClient.connect(mongoUrl);
        console.log('Conectado ao MongoDB com sucesso');
        db = client.db(dbName);
    } catch (err) {
        console.error('Erro ao conectar ao MongoDB:', err);
    }
}
app.post('/tomar_posse', async (req, res) => {
    const { email, carro } = req.body;

    // Verifica se os dados do carro e o email foram passados
    if (!email || !carro) {
        return res.status(400).json({ sucesso: false, mensagem: 'Dados incompletos' });
    }

    const { modelo, fabricante, placa, ano, dono } = carro;

    try {
        // Conectando ao banco de dados
        const client = await MongoClient.connect(mongoUrl);
        const db = client.db(dbName);

        // Atualiza os dados do carro com o novo dono (usuário)
        const result = await db.collection('dados').updateOne(
            { placa: placa }, // Identifica o carro pela placa
            {
                $set: { // Atualiza as informações
                    modelo,
                    fabricante,
                    ano,
                    dono: email // Define o novo dono do carro
                }
            }
        );

        await client.close();

        // Se o carro foi encontrado e atualizado
        if (result.matchedCount > 0) {
            res.status(200).json({ sucesso: true, mensagem: 'Posse do carro atualizada com sucesso.' });
        } else {
            res.status(404).json({ sucesso: false, mensagem: 'Carro não encontrado.' });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ sucesso: false, mensagem: 'Erro ao atualizar a posse do carro.' });
    }
});
app.post('/car', async (req, res) => {
    const { modelo, fabricante, placa, ano } = req.body;

    try {
        const client = await MongoClient.connect(mongoUrl);
        const db = client.db(dbName);

        const result = await db.collection('dados').insertOne({
            modelo,
            fabricante,
            placa,
            ano
        });

        await client.close();
        res.status(200).json({ message: 'Carro cadastrado com sucesso.' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Erro ao cadastrar carro.' });
    }
});
app.post('/cadastro', async (req, res) => {
    const { nome, email, password } = req.body;

    try {
        const client = await MongoClient.connect(mongoUrl);
        const db = client.db(dbName);

        const result = await db.collection('users').insertOne({
            nome,
            email,
            password
        });

        await client.close();
        res.status(200).json({ message: 'Usuário cadastrado com sucesso!' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Erro ao cadastrar usuário.' });
    }
});
app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        const client = await MongoClient.connect(mongoUrl);
        const db = client.db(dbName);

        const usuario = await db.collection('users')
            .findOne({
                email: email,
                password: password
            });

        await client.close();

        if (usuario) {
            // Gerar um token JWT
            const token = jwt.sign({ email: usuario.email, nome: usuario.nome }, jwtSecret, { expiresIn: '1h' });

            res.json({
                sucesso: true,
                usuario: {
                    email: usuario.email,
                    nome: usuario.nome
                },
                token: token  // Retornar o token
            });
        } else {
            res.status(401).json({
                sucesso: false,
                mensagem: 'Senha ou Usuário incorreto'
            });
        }
    } catch (erro) {
        console.error('Erro detalhado:', erro);
        res.status(500).json({
            sucesso: false,
            mensagem: 'Erro interno do servidor'
        });
    }
});
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'static', 'Login.html'));
});
app.get('/get_all_data', async (req, res) => {
    try {
        const collection = db.collection('dados');
        const documents = await collection.find({}).toArray();
        res.json(documents);
    } catch (err) {
        res.status(500).json({ error: 'Erro ao buscar dados do MongoDB' });
    }
});
// Iniciar o servidor
async function startServer() {
    await connectToMongo();
    app.listen(PORT, HOST, () => {
        console.log(`Servidor rodando em http://${HOST}:${PORT}`);
    });
}

startServer();